#!/usr/bin/env python3
"""VISTA Web 启动入口（免安装）。

用法：
    python run_web.py                 # 默认 http://127.0.0.1:5001
    python run_web.py --port 8080
    python run_web.py --host 0.0.0.0  # 局域网可访问（注意安全）

它把 src/ 与 web/ 加进 sys.path，然后启动 Flask 应用。
凭据仍然只从环境变量读取：
    export VISTA_API_KEY=...
    export VISTA_BASE_URL=...      # 可选，OpenAI 兼容网关
若没有 key，在界面「设置 → Provider」里选 mock 即可离线体验完整流程。
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for sub in ("src", "web"):
    p = str(ROOT / sub)
    if p not in sys.path:
        sys.path.insert(0, p)

from app import main  # noqa: E402

if __name__ == "__main__":
    main()
