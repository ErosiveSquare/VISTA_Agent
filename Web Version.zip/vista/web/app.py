"""VISTA Web —— 给 VISTA coding agent 套一层浏览器界面。

设计原则：
    - 不改动 vista 包的任何一行核心代码，只作为它的调用方。
    - 复用 Agent(on_event=...) 这个已有回调，把事件流经 SSE 推给前端。
    - Agent 在后台线程里跑，Flask 主线程只负责收发事件，界面不会被阻塞。
    - 每个任务是一个 Job，前端通过 job_id 订阅它的事件流。

后端只用 Flask（题目允许），vista 本身仍然零必需依赖。
"""

from __future__ import annotations

import queue
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any

# ---- 把 src/ 加进路径，使得 `import vista` 拿到项目包 ----
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from flask import (  # noqa: E402
    Flask,
    Response,
    jsonify,
    render_template,
    request,
    send_file,
)

from vista import __version__  # noqa: E402
from vista.config import load_config  # noqa: E402
from vista.memory.archive import list_sessions, load_session  # noqa: E402
from vista.report import write_report  # noqa: E402

app = Flask(__name__, static_folder="static", template_folder="templates")

# 所有活动/历史 Job 都放在这里。单进程内存态即可，界面本就是单用户本地工具。
JOBS: dict[str, "Job"] = {}
JOBS_LOCK = threading.Lock()


# ===========================================================================
# Job：一次 agent 运行
# ===========================================================================
class Job:
    """封装一次 Agent.run()。

    事件通过线程安全队列在后台线程与 SSE 生成器之间传递。
    """

    def __init__(self, job_id: str, task: str, options: dict):
        self.id = job_id
        self.task = task
        self.options = options
        self.q: "queue.Queue[dict | None]" = queue.Queue()
        self.events: list[dict] = []          # 事件回放缓存（用于断线重连）
        self.status = "pending"               # pending | running | done | error
        self.result: dict | None = None
        self.session_id: str | None = None
        self.session_dir: str | None = None
        self.cwd: str | None = None
        self.created = time.time()
        self._thread: threading.Thread | None = None

    # ---------------------------------------------------------------
    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _emit(self, kind: str, text: str = "", **extra: Any) -> None:
        ev = {"kind": kind, "text": text, "extra": extra, "ts": time.time()}
        self.events.append(ev)
        self.q.put(ev)

    # ---------------------------------------------------------------
    def _run(self) -> None:
        self.status = "running"
        try:
            self._run_agent()
        except Exception as e:  # 兜底：任何异常都变成一个终止事件，界面不会卡死
            import traceback

            self.status = "error"
            self._emit(
                "fatal",
                f"运行时发生错误：{type(e).__name__}: {e}",
                traceback=traceback.format_exc()[:3000],
            )
        finally:
            self.q.put(None)   # 哨兵：告诉 SSE 生成器可以关闭了

    def _run_agent(self) -> None:
        # 延迟 import，避免 Flask 启动就把整个 agent 依赖树拉起来
        from vista.llm.client import LLM
        from vista.loop import Agent

        opt = self.options
        cwd = opt.get("cwd") or str(ROOT)
        cwd_path = Path(cwd).expanduser()
        if not cwd_path.is_dir():
            self.status = "error"
            self._emit("fatal", f"工作区目录不存在：{cwd_path}")
            return

        overrides = _overrides_from_options(opt)
        cfg = load_config(cwd_path, overrides)
        cfg.interactive = False          # Web 端一律非交互，权限由 mode/yolo 决定
        cfg.color = False

        self.cwd = str(cfg.cwd)

        # 没有 API key 又不是 mock/离线，提前给出友好提示
        if cfg.model.provider != "mock" and not cfg.api_key:
            self._emit(
                "warn",
                "未检测到 API key（环境变量 VISTA_API_KEY）。"
                "若只想看界面与离线流程，请把 Provider 选为 mock。",
            )

        def on_event(kind: str, text: str, extra: dict) -> None:
            self._emit(kind, text, **(extra or {}))

        try:
            llm = LLM(cfg)
        except Exception as e:
            self.status = "error"
            self._emit("fatal", f"初始化模型客户端失败：{e}")
            return

        self._emit(
            "meta",
            "",
            provider=cfg.model.provider,
            model=cfg.model.main,
            weak_model=cfg.model.weak_model,
            cwd=str(cfg.cwd),
            baseline=cfg.baseline_mode,
            version=__version__,
        )

        agent = Agent(cfg, llm=llm, ui=None, on_event=on_event)
        self.session_id = agent.session_id
        self.session_dir = str(agent.session_dir)
        self._emit("session", "", session_id=agent.session_id,
                   session_dir=str(agent.session_dir))

        res = agent.run(self.task)

        # 结束后自动生成一份 HTML 报告，界面里可直接打开
        report_path = None
        try:
            report_path = str(write_report(agent.session_dir))
        except Exception:
            report_path = None

        self.result = {
            "status": res.status,
            "ok": res.ok,
            "verified": res.verified,
            "reason": res.reason,
            "summary": res.summary,
            "steps": res.steps,
            "in_tokens": res.usage.in_tokens,
            "out_tokens": res.usage.out_tokens,
            "cost": round(res.cost, 6),
            "wall_ms": res.wall_ms,
            "mutated": res.mutated,
            "session_id": res.session_id,
            "session_dir": res.session_dir,
            "report": report_path,
            "compactions": agent.history.n_compactions,
            "snapshots": agent.snapshots.count,
            "tool_stats": agent.ctx.stats.to_dict(),
        }
        self.status = "done"
        self._emit("result", "", **self.result)


# ---------------------------------------------------------------------------
def _overrides_from_options(opt: dict) -> dict:
    """把前端传来的表单选项映射成 load_config 的 overrides。

    键名与 CLI 的 overrides_from 保持一致，这样两条入口共用同一套配置语义。
    """
    o: dict = {}
    if opt.get("model"):
        o["model.main"] = opt["model"]
    if opt.get("weak_model"):
        o["model.weak"] = opt["weak_model"]
    if opt.get("provider"):
        o["model.provider"] = opt["provider"]
    if opt.get("base_url"):
        o["model.base_url"] = opt["base_url"]
    if opt.get("max_steps") not in (None, ""):
        try:
            o["limits.max_steps"] = int(opt["max_steps"])
        except (TypeError, ValueError):
            pass
    if opt.get("budget") not in (None, ""):
        try:
            o["limits.max_cost"] = float(opt["budget"])
        except (TypeError, ValueError):
            pass
    if opt.get("permission_mode"):
        o["permission.mode"] = opt["permission_mode"]
    if opt.get("yolo"):
        o["permission.yolo"] = True

    # 消融开关
    if opt.get("no_repomap"):
        o["repomap.enabled"] = False
    if opt.get("no_compact"):
        o["context.enabled"] = False
    if opt.get("no_skills"):
        o["skills.enabled"] = False
    if opt.get("no_verify"):
        o["verify.enabled"] = False
    if opt.get("baseline"):
        o["baseline_mode"] = True
        o["repomap.enabled"] = False
        o["context.enabled"] = False
        o["skills.enabled"] = False
    return o


# ===========================================================================
# 路由
# ===========================================================================
@app.route("/")
def index() -> str:
    return render_template("index.html", version=__version__)


@app.route("/api/env")
def api_env() -> Response:
    """给前端的启动信息：默认工作区、是否有 key、默认模型等。"""
    cfg = load_config(ROOT, {})
    return jsonify({
        "version": __version__,
        "default_cwd": str(ROOT),
        "has_api_key": bool(cfg.api_key),
        "provider": cfg.model.provider,
        "model": cfg.model.main,
        "weak_model": cfg.model.weak_model,
        "base_url": cfg.model.base_url,
        "max_steps": cfg.limits.max_steps,
        "budget": cfg.limits.max_cost,
    })


@app.route("/api/run", methods=["POST"])
def api_run() -> Response:
    data = request.get_json(force=True, silent=True) or {}
    task = (data.get("task") or "").strip()
    if not task:
        return jsonify({"error": "任务描述不能为空。"}), 400

    job_id = uuid.uuid4().hex[:12]
    job = Job(job_id, task, data.get("options") or {})
    with JOBS_LOCK:
        JOBS[job_id] = job
    job.start()
    return jsonify({"job_id": job_id})


@app.route("/api/stream/<job_id>")
def api_stream(job_id: str) -> Response:
    job = JOBS.get(job_id)
    if job is None:
        return jsonify({"error": "job not found"}), 404

    # 支持断线重连：前端可用 ?from=N 从第 N 条事件继续
    try:
        start_from = int(request.args.get("from", 0))
    except (TypeError, ValueError):
        start_from = 0

    def gen():
        import json as _json

        # 先补发已经产生的历史事件（覆盖到重连之前发生的一切）
        idx = 0
        for ev in job.events[start_from:]:
            idx = start_from + job.events[start_from:].index(ev) + 1
            yield _sse(_json.dumps(ev, ensure_ascii=False))

        # 若任务已结束，直接收尾
        if job.status in ("done", "error") and job.q.empty():
            yield _sse(_json.dumps({"kind": "_close"}, ensure_ascii=False))
            return

        # 继续消费实时事件
        while True:
            try:
                ev = job.q.get(timeout=20)
            except queue.Empty:
                yield ": keep-alive\n\n"       # 心跳，防止代理断连
                continue
            if ev is None:
                yield _sse(_json.dumps({"kind": "_close"}, ensure_ascii=False))
                break
            yield _sse(_json.dumps(ev, ensure_ascii=False))

    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no",
                             "Connection": "keep-alive"})


@app.route("/api/job/<job_id>")
def api_job(job_id: str) -> Response:
    job = JOBS.get(job_id)
    if job is None:
        return jsonify({"error": "job not found"}), 404
    return jsonify({
        "id": job.id,
        "task": job.task,
        "status": job.status,
        "session_id": job.session_id,
        "result": job.result,
        "n_events": len(job.events),
    })


@app.route("/api/sessions")
def api_sessions() -> Response:
    cwd = request.args.get("cwd") or str(ROOT)
    cfg = load_config(Path(cwd), {})
    rows = list_sessions(cfg.sessions_dir, limit=100)
    return jsonify({"sessions": rows, "cwd": str(cfg.cwd)})


@app.route("/api/session/<session_id>")
def api_session(session_id: str) -> Response:
    cwd = request.args.get("cwd") or str(ROOT)
    cfg = load_config(Path(cwd), {})
    d = cfg.sessions_dir / session_id
    if not d.is_dir():
        return jsonify({"error": "session not found"}), 404
    data = load_session(d)
    # 事件正文可能很大，做一层瘦身，只保留界面需要的字段
    events = []
    for e in data["events"]:
        events.append({
            "idx": e.get("idx"),
            "kind": e.get("kind"),
            "role": e.get("role"),
            "content": (e.get("content") or "")[:4000],
            "tool_name": e.get("tool_name"),
            "code": e.get("code"),
            "pinned": e.get("pinned"),
            "superseded_by": e.get("superseded_by"),
            "calls": e.get("calls") or [],
        })
    return jsonify({
        "session_id": session_id,
        "meta": data["meta"],
        "end": data["end"],
        "events": events,
        "context": data["context"],
        "compactions": data["compactions"],
        "verifies": data["verifies"],
    })


@app.route("/api/report/<session_id>")
def api_report(session_id: str) -> Response:
    cwd = request.args.get("cwd") or str(ROOT)
    cfg = load_config(Path(cwd), {})
    d = cfg.sessions_dir / session_id
    if not d.is_dir():
        return jsonify({"error": "session not found"}), 404
    path = d / "report.html"
    if not path.is_file():
        try:
            path = write_report(d)
        except Exception as e:
            return jsonify({"error": f"生成报告失败：{e}"}), 500
    return send_file(str(path), mimetype="text/html")


# ---------------------------------------------------------------------------
def _sse(data: str) -> str:
    return f"data: {data}\n\n"


# ---------------------------------------------------------------------------
def main() -> None:
    import argparse

    p = argparse.ArgumentParser(description="VISTA Web 界面")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=5001)
    p.add_argument("--debug", action="store_true")
    args = p.parse_args()

    print(f"  VISTA Web  ·  http://{args.host}:{args.port}")
    print(f"  工作区默认：{ROOT}")
    print("  按 Ctrl-C 退出。\n")
    # threaded=True 让 SSE 与普通请求可以并发
    app.run(host=args.host, port=args.port, debug=args.debug, threaded=True)


if __name__ == "__main__":
    main()
