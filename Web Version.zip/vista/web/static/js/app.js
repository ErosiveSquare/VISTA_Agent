/* ==========================================================================
   VISTA Web —— 前端逻辑（纯原生 JS，无框架）。
   职责：
     - 收集任务与设置，POST /api/run 拿到 job_id
     - 通过 EventSource 订阅 /api/stream/<job_id>，把事件渲染成流
     - 维护历史会话侧栏、报告弹层、设置抽屉
   ========================================================================== */
(() => {
  "use strict";

  // ---- 小工具 ----
  const $  = (sel, el = document) => el.querySelector(sel);
  const $$ = (sel, el = document) => Array.from(el.querySelectorAll(sel));
  const el = (tag, cls, html) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  };
  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  // localStorage 在某些内嵌环境不可用，做一层容错包装
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* 忽略 */ } },
  };

  // ---- 状态 ----
  const state = {
    env: null,
    settings: store.get("vista.settings", {}),
    jobId: null,
    source: null,
    running: false,
    cwd: null,
    lastResult: null,
  };

  // 事件类型 → 字形（与 CLI 的 KIND_STYLE 对应，保持体验一致）
  const GLYPH = {
    step: "·", tool: "▸", tool_error: "✗", compaction: "⟐",
    verify: "⊙", verify_pass: "✓", verify_fail: "✗",
    baseline: "·", baseline_done: "·", warn: "!", memory: "◆",
    skill: "◆", end: "■", info: "·", fatal: "✗", assistant: "…",
    session: "◇", meta: "·",
  };

  // ============================ 元素引用 ============================
  const elets = {
    stream: $("#stream"), events: $("#events"), welcome: $("#welcome"),
    input: $("#taskInput"), send: $("#btnSend"), stop: $("#btnStop"),
    resultBar: $("#resultBar"), topTitle: $("#topTitle"),
    sessionList: $("#sessionList"),
    envDot: $("#envDot"), envText: $("#envText"),
    metaProvider: $("#metaProvider"), metaCwd: $("#metaCwd"),
    toast: $("#toast"),
  };

  // ============================ 初始化 ============================
  async function init() {
    bindUI();
    await loadEnv();
    hydrateSettings();
    await loadSessions();
    autoGrow(elets.input);
    elets.input.focus();
  }

  async function loadEnv() {
    try {
      const r = await fetch("/api/env");
      state.env = await r.json();
      state.cwd = state.settings.cwd || state.env.default_cwd;
      const hasKey = state.env.has_api_key;
      elets.envDot.className = "dot " + (hasKey ? "ok" : "off");
      elets.envText.textContent = hasKey ? "API key 已就绪" : "无 API key · 可用 mock";
      updateComposerMeta();
    } catch {
      elets.envText.textContent = "后端未连接";
    }
  }

  function updateComposerMeta() {
    const s = currentSettings();
    elets.metaProvider.textContent = `${s.provider} · ${s.model || (state.env && state.env.model) || "—"}`;
    const cwd = s.cwd || (state.env && state.env.default_cwd) || "";
    elets.metaCwd.textContent = cwd ? shortPath(cwd) : "—";
    elets.metaCwd.title = cwd;
  }

  function shortPath(p) {
    const parts = String(p).split("/").filter(Boolean);
    return parts.length <= 2 ? p : "…/" + parts.slice(-2).join("/");
  }

  // ============================ 设置 ============================
  function currentSettings() {
    const env = state.env || {};
    const s = state.settings || {};
    return {
      cwd: s.cwd || env.default_cwd || "",
      provider: s.provider || env.provider || "http",
      model: s.model || env.model || "",
      weak_model: s.weak_model || "",
      base_url: s.base_url || env.base_url || "",
      max_steps: s.max_steps || "",
      budget: s.budget || "",
      permission_mode: s.permission_mode || "ask",
      yolo: !!s.yolo,
      no_repomap: !!s.no_repomap, no_compact: !!s.no_compact,
      no_skills: !!s.no_skills, no_verify: !!s.no_verify,
      baseline: !!s.baseline,
    };
  }

  function hydrateSettings() {
    const s = currentSettings();
    $("#optCwd").value = s.cwd;
    $("#optModel").value = s.model;
    $("#optWeak").value = s.weak_model;
    $("#optBaseUrl").value = s.base_url;
    $("#optMaxSteps").value = s.max_steps;
    $("#optBudget").value = s.budget;
    $("#optYolo").checked = s.yolo;
    $("#optNoRepomap").checked = s.no_repomap;
    $("#optNoCompact").checked = s.no_compact;
    $("#optNoSkills").checked = s.no_skills;
    $("#optNoVerify").checked = s.no_verify;
    $("#optBaseline").checked = s.baseline;
    setSegmented("#segProvider", s.provider);
    setSegmented("#segPerm", s.permission_mode);
  }

  function collectSettings() {
    return {
      cwd: $("#optCwd").value.trim(),
      provider: getSegmented("#segProvider"),
      model: $("#optModel").value.trim(),
      weak_model: $("#optWeak").value.trim(),
      base_url: $("#optBaseUrl").value.trim(),
      max_steps: $("#optMaxSteps").value.trim(),
      budget: $("#optBudget").value.trim(),
      permission_mode: getSegmented("#segPerm"),
      yolo: $("#optYolo").checked,
      no_repomap: $("#optNoRepomap").checked,
      no_compact: $("#optNoCompact").checked,
      no_skills: $("#optNoSkills").checked,
      no_verify: $("#optNoVerify").checked,
      baseline: $("#optBaseline").checked,
    };
  }

  function setSegmented(sel, value) {
    $$(`${sel} button`).forEach(b => b.classList.toggle("active", b.dataset.value === value));
  }
  function getSegmented(sel) {
    const a = $(`${sel} button.active`);
    return a ? a.dataset.value : $(`${sel} button`).dataset.value;
  }

  // ============================ 运行任务 ============================
  async function runTask(task) {
    if (state.running) return;
    task = (task || elets.input.value).trim();
    if (!task) return;

    // 界面切换到运行态
    elets.welcome.hidden = true;
    elets.events.innerHTML = "";
    elets.resultBar.hidden = true;
    elets.resultBar.className = "result-bar";
    elets.topTitle.textContent = task.length > 60 ? task.slice(0, 60) + "…" : task;
    setRunning(true);

    // 用户任务气泡
    addUserBubble(task);
    const thinking = addThinking();

    elets.input.value = "";
    autoGrow(elets.input);

    let payload;
    try {
      const r = await fetch("/api/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task, options: currentSettings() }),
      });
      payload = await r.json();
      if (!r.ok) throw new Error(payload.error || "启动失败");
    } catch (e) {
      thinking.remove();
      addEvent({ kind: "fatal", text: "无法启动任务：" + e.message });
      setRunning(false);
      return;
    }

    state.jobId = payload.job_id;
    subscribe(payload.job_id, thinking);
  }

  function subscribe(jobId, thinkingEl) {
    if (state.source) state.source.close();
    const src = new EventSource(`/api/stream/${jobId}`);
    state.source = src;

    src.onmessage = (e) => {
      let ev;
      try { ev = JSON.parse(e.data); } catch { return; }
      if (ev.kind === "_close") { finishStream(); return; }
      handleEvent(ev, thinkingEl);
    };
    src.onerror = () => {
      // 连接中断：若任务已结束则正常收尾，否则提示
      if (!state.running) return;
      src.close();
      // 轮询一次 job 状态，决定是否真的失败
      fetch(`/api/job/${jobId}`).then(r => r.json()).then(j => {
        if (j.status === "done" && j.result) {
          renderResult(j.result);
          finishStream();
        } else if (j.status === "error") {
          finishStream();
        } else {
          addEvent({ kind: "warn", text: "事件流连接中断，正在尝试重连…" });
          setTimeout(() => subscribe(jobId, null), 1200);
        }
      }).catch(() => finishStream());
    };
  }

  let thinkingRef = null;
  function handleEvent(ev, thinkingEl) {
    if (thinkingEl && thinkingEl.parentNode) { thinkingRef = thinkingEl; }

    switch (ev.kind) {
      case "meta":
        if (ev.extra) {
          const x = ev.extra;
          elets.metaProvider.textContent = `${x.provider} · ${x.model}`;
          if (x.cwd) { elets.metaCwd.textContent = shortPath(x.cwd); elets.metaCwd.title = x.cwd; }
        }
        return;
      case "session":
        state.sessionId = ev.extra && ev.extra.session_id;
        return;
      case "result":
        renderResult(ev.extra || {});
        return;
      case "end":
        return; // 概览条已由 result 事件渲染
    }

    // 移除“正在思考”占位（第一条实质事件到达时）
    if (thinkingRef && thinkingRef.parentNode &&
        !["step"].includes(ev.kind)) {
      thinkingRef.remove(); thinkingRef = null;
    }

    addEvent(ev);
  }

  function finishStream() {
    if (state.source) { state.source.close(); state.source = null; }
    if (thinkingRef && thinkingRef.parentNode) { thinkingRef.remove(); thinkingRef = null; }
    setRunning(false);
    loadSessions();
  }

  function setRunning(on) {
    state.running = on;
    elets.send.disabled = on;
    elets.stop.hidden = !on;
  }

  // ============================ 渲染 ============================
  function addUserBubble(task) {
    const row = el("div", "ev assistant");
    row.style.marginBottom = "10px";
    row.innerHTML = `
      <div class="ev-gutter"><div class="ev-glyph" style="background:var(--accent);color:#fff">你</div></div>
      <div class="ev-body"><div class="assistant-bubble" style="background:var(--accent-soft);border-color:transparent">${esc(task)}</div></div>`;
    elets.events.appendChild(row);
  }

  function addThinking() {
    const row = el("div", "ev");
    row.innerHTML = `
      <div class="ev-gutter"><div class="ev-glyph">◇</div></div>
      <div class="ev-body"><div class="thinking">VISTA 正在工作 <span class="dots"><i></i><i></i><i></i></span></div></div>`;
    elets.events.appendChild(row);
    scrollToEnd();
    return row;
  }

  function addEvent(ev) {
    const kind = ev.kind || "info";
    const glyph = GLYPH[kind] || "·";
    const row = el("div", `ev ${kind}`);

    let bodyHtml;
    if (kind === "assistant") {
      // 模型的文本输出（思考/结论）
      const text = (ev.text || "").trim();
      if (!text) return;
      bodyHtml = `<div class="assistant-bubble">${esc(text)}</div>`;
    } else if (kind === "tool") {
      bodyHtml = `<div class="ev-text">${formatTool(ev.text)}</div>`;
    } else if (kind === "step") {
      const tok = ev.extra && ev.extra.tokens;
      const suffix = tok ? `　<span style="opacity:.7">${Number(tok).toLocaleString()} tok</span>` : "";
      bodyHtml = `<div class="ev-text">${esc(ev.text)}${suffix}</div>`;
    } else {
      bodyHtml = `<div class="ev-text">${esc(ev.text)}</div>`;
      if (ev.extra && ev.extra.traceback) {
        bodyHtml += `<div class="ev-sub"><code>${esc(String(ev.extra.traceback).split("\n").slice(-3).join("\n"))}</code></div>`;
      }
    }

    row.innerHTML = `
      <div class="ev-gutter"><div class="ev-glyph">${glyph}</div></div>
      <div class="ev-body">${bodyHtml}</div>`;
    elets.events.appendChild(row);
    scrollToEnd();
  }

  function formatTool(text) {
    // 把 "read_file(path=…)" 里的工具名高亮
    const m = String(text).match(/^([a-z_]+)\((.*)\)$/s);
    if (m) return `<span class="tool-name">${esc(m[1])}</span><code class="tool-args">(${esc(m[2])})</code>`;
    return esc(text);
  }

  function renderResult(res) {
    state.lastResult = res;
    const good = res.ok;
    const warn = res.status === "success" && res.verified === false;
    const cls = warn ? "warn" : (good ? "ok" : "bad");
    const badge = warn ? "◐" : (good ? "✓" : "✗");
    const head = {
      success: warn ? "任务完成，但未经真实验证" : "任务完成，Verify-Gate 通过",
      answered: "已回答",
    }[res.status] || `未完成（${res.status}）`;

    const stat = (v, k) => `<div class="rb-stat"><span class="v">${v}</span><span class="k">${k}</span></div>`;
    const cost = res.cost != null ? `$${Number(res.cost).toFixed(4)}` : "—";
    const secs = res.wall_ms != null ? (res.wall_ms / 1000).toFixed(1) + "s" : "—";
    const tok = `${Number(res.in_tokens || 0).toLocaleString()} / ${Number(res.out_tokens || 0).toLocaleString()}`;

    elets.resultBar.className = `result-bar ${cls}`;
    elets.resultBar.hidden = false;
    elets.resultBar.innerHTML = `
      <div class="rb-head">
        <div class="rb-badge ${cls}">${badge}</div>
        <div><div class="rb-title">${esc(head)}</div><div class="rb-reason">${esc(res.reason || "")}</div></div>
      </div>
      <div class="rb-stats">
        ${stat(res.steps ?? "—", "步数")}
        ${stat(tok, "token 入/出")}
        ${stat(cost, "成本")}
        ${stat(secs, "耗时")}
        ${stat(res.compactions ?? 0, "压缩次数")}
      </div>
      <div class="rb-actions">
        ${res.session_id ? `<button class="pill-btn" id="rbReport">查看报告</button>` : ""}
      </div>`;

    const rb = $("#rbReport");
    if (rb) rb.addEventListener("click", () => openReport(res.session_id));

    if (res.summary) {
      addEvent({ kind: "end", text: res.summary.trim() });
    }
    scrollToEnd();
  }

  // ============================ 历史会话 ============================
  async function loadSessions() {
    try {
      const cwd = currentSettings().cwd;
      const r = await fetch("/api/sessions?cwd=" + encodeURIComponent(cwd || ""));
      const data = await r.json();
      const rows = data.sessions || [];
      if (!rows.length) {
        elets.sessionList.innerHTML = `<div class="side-empty">暂无会话</div>`;
        return;
      }
      elets.sessionList.innerHTML = "";
      rows.forEach(s => {
        const okKind = (s.status === "success" || s.status === "answered") ? "ok"
          : (["stuck", "verify_exhausted", "parse_failure", "api_failure", "error"].includes(s.status) ? "bad" : "warn");
        const item = el("div", "session-item");
        item.innerHTML = `
          <div class="si-task">${esc(s.task || "（无描述）")}</div>
          <div class="si-meta"><span class="si-status ${okKind}"></span>${esc(s.status)} · ${s.steps || 0} 步 · $${Number(s.cost || 0).toFixed(4)}</div>`;
        item.addEventListener("click", () => openReport(s.session_id, item));
        elets.sessionList.appendChild(item);
      });
    } catch { /* 忽略 */ }
  }

  // ============================ 报告弹层 ============================
  function openReport(sessionId, itemEl) {
    if (!sessionId) return;
    $$(".session-item").forEach(x => x.classList.remove("active"));
    if (itemEl) itemEl.classList.add("active");
    const cwd = currentSettings().cwd;
    const url = `/api/report/${sessionId}?cwd=${encodeURIComponent(cwd || "")}`;
    $("#modalFrame").src = url;
    $("#modalOpenReport").href = url;
    $("#modalTitle").textContent = "会话报告 · " + sessionId;
    showModal(true);
  }

  function showModal(on) {
    $("#modalScrim").hidden = !on;
    if (!on) $("#modalFrame").src = "about:blank";
  }

  // ============================ 抽屉 ============================
  function showDrawer(on) {
    $("#drawerScrim").hidden = !on;
    $("#settingsDrawer").hidden = !on;
  }

  // ============================ 交互绑定 ============================
  function bindUI() {
    elets.send.addEventListener("click", () => runTask());
    $("#btnNew").addEventListener("click", newTask);

    elets.input.addEventListener("input", () => autoGrow(elets.input));
    elets.input.addEventListener("keydown", (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") { e.preventDefault(); runTask(); }
    });

    $$("#chipRow .chip").forEach(c =>
      c.addEventListener("click", () => runTask(c.dataset.task)));

    elets.stop.addEventListener("click", () => {
      // 前端停止：关闭事件流（后端 agent 会在下一步自然收尾或达上限）
      finishStream();
      toast("已停止接收事件");
    });

    // 设置抽屉
    $("#btnSettings").addEventListener("click", () => showDrawer(true));
    $("#btnCloseSettings").addEventListener("click", () => showDrawer(false));
    $("#drawerScrim").addEventListener("click", () => showDrawer(false));
    $("#btnSaveSettings").addEventListener("click", () => {
      state.settings = collectSettings();
      store.set("vista.settings", state.settings);
      updateComposerMeta();
      loadSessions();
      showDrawer(false);
      toast("设置已保存");
    });
    $("#btnResetSettings").addEventListener("click", () => {
      state.settings = {};
      store.set("vista.settings", {});
      hydrateSettings();
      updateComposerMeta();
      toast("已恢复默认");
    });

    // 分段控件
    $$(".segmented").forEach(seg => {
      $$("button", seg).forEach(b => b.addEventListener("click", () => {
        $$("button", seg).forEach(x => x.classList.remove("active"));
        b.classList.add("active");
      }));
    });

    // baseline 勾选时联动禁用其它消融
    $("#optBaseline").addEventListener("change", (e) => {
      const on = e.target.checked;
      ["#optNoRepomap", "#optNoCompact", "#optNoSkills"].forEach(s => {
        $(s).checked = on ? true : $(s).checked;
        $(s).disabled = on;
      });
    });

    // 报告弹层
    $("#btnCloseModal").addEventListener("click", () => showModal(false));
    $("#modalScrim").addEventListener("click", (e) => { if (e.target === $("#modalScrim")) showModal(false); });

    // 移动端菜单
    $("#btnMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));

    // ESC 关闭浮层
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        if (!$("#modalScrim").hidden) showModal(false);
        else if (!$("#settingsDrawer").hidden) showDrawer(false);
      }
    });
  }

  function newTask() {
    if (state.source) state.source.close();
    setRunning(false);
    state.jobId = null;
    elets.events.innerHTML = "";
    elets.resultBar.hidden = true;
    elets.welcome.hidden = false;
    elets.topTitle.textContent = "新任务";
    $("#sidebar").classList.remove("open");
    elets.input.focus();
  }

  // ============================ 杂项 ============================
  function autoGrow(ta) {
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 180) + "px";
  }
  function scrollToEnd() {
    requestAnimationFrame(() => { elets.stream.scrollTop = elets.stream.scrollHeight; });
  }
  let toastTimer = null;
  function toast(msg) {
    elets.toast.textContent = msg;
    elets.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { elets.toast.hidden = true; }, 2000);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
