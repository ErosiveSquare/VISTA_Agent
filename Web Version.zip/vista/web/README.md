# VISTA Web —— 浏览器界面

给命令行的 VISTA coding agent 套一层干净、克制、iOS 风格的 Web 界面。
纯 HTML / CSS / 原生 JS，后端只用 Flask，**不改动 `src/vista` 的任何一行核心代码**。

## 快速开始

```bash
# 1. 安装 Web 界面的唯一新增依赖（vista 核心仍零必需依赖）
pip install flask            # 或 pip install -r web/requirements.txt

# 2. 配置凭据（只从环境变量读，不入库）
export VISTA_API_KEY=sk-...
export VISTA_BASE_URL=https://api.openai.com/v1   # 可选，OpenAI 兼容网关

# 3. 启动
python run_web.py            # 打开 http://127.0.0.1:5001
```

**没有 API key？** 在界面「设置 → Provider」里选 **mock（离线）**，
可以在内置演示项目上跑通完整流程（TODO 拆解 → 索引 → 定位 → 编辑 →
上下文压缩 → Verify-Gate → 技能卡蒸馏），不需要网络，结果确定可复现。

## 它是怎么接上去的

界面复用了 agent 已经暴露的 `Agent(cfg, llm, ui, on_event=...)` 回调：

```
浏览器  ──POST /api/run──►  Flask  ──后台线程──►  vista.loop.Agent.run()
   ▲                                                    │ on_event(kind,text,extra)
   └──────  SSE /api/stream/<job_id>  ◄── 事件队列 ◄──────┘
```

- **一次任务 = 一个 Job**，在后台线程里跑，主线程只转发事件，界面不阻塞。
- **Server-Sent Events** 把 agent 的每一步（工具调用、压缩、验收、蒸馏）
  实时推给前端渲染，和命令行看到的事件流一一对应。
- 任务结束自动生成单文件 HTML 报告，界面里可直接打开（token 曲线、步骤时间线、徽章）。
- Web 端为**非交互运行**：权限由「设置」里的 `ask/allow/deny` 与 YOLO 决定，
  与 CLI 的 `--yolo` / `permission.mode` 语义完全一致。

## 目录

```
web/
├── app.py               Flask 后端：run / stream(SSE) / sessions / report
├── requirements.txt     只有 flask
├── templates/
│   └── index.html       单页界面
└── static/
    ├── css/style.css    iOS 风格样式（含暗色模式）
    └── js/app.js        原生 JS：SSE 订阅、事件渲染、设置、报告弹层
```

## 接口一览

| 方法 | 路径 | 用途 |
|---|---|---|
| GET  | `/`                       | 主界面 |
| GET  | `/api/env`                | 默认工作区 / 是否有 key / 默认模型 |
| POST | `/api/run`                | 提交任务，返回 `job_id` |
| GET  | `/api/stream/<job_id>`    | SSE 事件流（支持 `?from=N` 断线重连） |
| GET  | `/api/job/<job_id>`       | 查询某个 Job 的状态与结果 |
| GET  | `/api/sessions?cwd=…`     | 历史会话列表 |
| GET  | `/api/session/<id>?cwd=…` | 单个会话的结构化数据 |
| GET  | `/api/report/<id>?cwd=…`  | 该会话的单文件 HTML 报告 |

## 设计取舍

- **为什么用 SSE 而不是 WebSocket**：事件是单向的（服务器 → 浏览器），
  SSE 更简单、自动重连、走普通 HTTP，够用且更稳。
- **为什么 Web 端不做交互式权限确认**：浏览器里做阻塞式往返确认既脆弱又割裂体验；
  直接沿用 agent 已有的非交互权限策略（`ask/allow/deny` + YOLO），
  把安全边界交给用户在运行前设定，更清晰也更可靠。
- **为什么不引前端框架**：界面本身不复杂，一个页面 + 一条事件流 + 几个浮层，
  原生 JS 足以胜任，也和 vista「零必需依赖」的气质一致。
```
